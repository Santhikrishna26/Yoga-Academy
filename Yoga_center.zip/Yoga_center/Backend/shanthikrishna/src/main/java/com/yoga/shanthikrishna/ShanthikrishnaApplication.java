package com.yoga.shanthikrishna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShanthikrishnaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShanthikrishnaApplication.class, args);
	}

}

import { lazy, Suspense } from "react";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import loading from './assets/images/loading.gif';

const LazyLoginForm = lazy(() => import("./components/Login"));
const LazySignUp = lazy(() => import("./components/Signup"));
const LazyTopbar = lazy(() => import("./components/Topbar"));
const LazySidebar = lazy(() => import("./components/Sidebar"));
const LazyHomePage = lazy(() => import("./components/Home"));
const LazyCourse = lazy(() => import("./components/Course"));
const LazyProfile = lazy(() => import("./components/Profile"));
const LazyActionAreaCard = lazy(() => import("./components/Classes"));
const LazyEventPage = lazy(() => import("./components/event"));
const LazyParticipateForm = lazy(() => import("./components/eventform"));
const LazyAdminDashboard = lazy(() => import("./components/adminDash"));
const LazyAdminSidebar = lazy(() => import("./components/AdminSidebar"));
const LazyContacts = lazy(() => import("./components/Contacts"));

function App() {
  return (
    <div className="App">
      <Router>
        <Suspense fallback={<img src={loading} display="flex" alignItems="center" justifyContent='center' width="500px" alt="Loading..." />}>
          <Routes>
            <Route path="/" element={<LazyLoginForm />} />
            <Route path="/SignUp" element={<LazySignUp />} />
            <Route path="/" element={<LazyTopbar />} />
            <Route path="/Sidebar" element={<LazySidebar />} />
            <Route path="/HomePage" element={<LazyHomePage />} />
            <Route path="/Course" element={<LazyCourse />} />
            <Route path="/Profile" element={<LazyProfile />} />
            <Route path="/event" element={<LazyEventPage />} />
            <Route path="/EventForm" element={<LazyParticipateForm />} />
            <Route path="/classes" element={<LazyActionAreaCard />} />
            <Route path="/AdminDashboard" element={<LazyAdminDashboard />} />
            <Route path="/AdminSidebar" element={<LazyAdminSidebar />} />
            <Route path="/Contacts" element={<LazyContacts />} />
          </Routes>
        </Suspense>
      </Router>
    </div>
  );
}

export default App;
